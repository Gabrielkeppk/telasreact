import * as React from 'react';
import { Text, View, StyleSheet, Image,SafeAreaView,TextInput } from 'react-native';
export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
      </Text>
      <Image style={styles.logo} source={require('../Ilustração-Caveira-PNG.png')} />


      <SafeAreaView>
      <TextInput
        style={styles.input}
        value={Number}
         placeholder="Email"
       
         
      />
      <TextInput
        style={styles.input}
        value={Number}
        placeholder="Senha"
        keyboardType="numeric"
      />
    </SafeAreaView>
     
    </View>
 
   
  );
}


const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logo: {
    height: 250,
    width: 250,
  },
  input: {
    height: 30,
    width: 200,
    margin: 20,
    borderWidth: 1,
    padding: 10,
    backgroundColor:"orange",
    textAlign: "center",
    fontWeight: 'bold',
    color: "black"
  }
});

