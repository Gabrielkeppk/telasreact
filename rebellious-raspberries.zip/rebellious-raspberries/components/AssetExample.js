import * as React from 'react';
import { Text, View, StyleSheet, Image, SafeAreaView, TextInput } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
     
      </Text>
      <Image style={styles.logo} source={require('../Caveira-de-Fogo-PNG.png')} />
       <SafeAreaView>
      <TextInput
        
       
         
      />
      <TextInput
        style={styles.input}
        value={Number}
        placeholder="Clique para Jogar"
        keyboardType="numeric"
      />
    </SafeAreaView>
     
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logo: {
    height: 200,
    width: 178,
  },
  
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
    backgroundColor:"orange",
    
  },


});
